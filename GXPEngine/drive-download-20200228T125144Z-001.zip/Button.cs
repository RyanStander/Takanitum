﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Button : Sprite
    {
        public Button (string filename) : base(filename)
        {

        }
    }
}
