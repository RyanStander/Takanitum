﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    //------------------------------------------------
    //             ImgBackground : Sprite   
    //------------------------------------------------
    class ImgBackground : Sprite
    {

        //------------------------------------------------
        //               ImgBackground()   
        //------------------------------------------------
        public ImgBackground(string filename) : base(filename)
        {
            
        }
    }
}