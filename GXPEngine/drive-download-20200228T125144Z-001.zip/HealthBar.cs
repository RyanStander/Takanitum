﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class HealthBar : Sprite
    {


       

        public HealthBar() : base("Player1Health.png")
        {



        }


        public void Update()
        {



        }




    }
}
