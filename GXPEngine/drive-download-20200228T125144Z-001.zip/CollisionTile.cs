﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class CollisionTile :AnimationSprite
    {
        public CollisionTile(string filename, int cols, int rows) : base(filename, cols, rows)
        {

        }
    }
}
